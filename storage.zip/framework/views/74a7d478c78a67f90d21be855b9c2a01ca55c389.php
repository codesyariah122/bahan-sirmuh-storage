<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Nota Pembayaran Hutang -  <?php echo e($kode); ?></title>

    <style>
        table td {
            /* font-family: Arial, Helvetica, sans-serif; */
            font-size: 14px;
        }
        table.data td,
        table.data th {
            border: 1px solid #ccc;
            padding: 5px;
        }
        table.data {
            border-collapse: collapse;
        }
        .text-center {
            text-align: center;
        }
        .text-right {
            text-align: right;
        }
    </style>
</head>
<body>
    <table width="100%">
        <tr>
            <td rowspan="4" width="60%">
                <img src="<?php echo e(public_path('storage/tokos/' . $toko['logo'])); ?>" alt="<?php echo e($toko['logo']); ?>" width="100">
                <br>
                <?php echo e($toko['name']); ?>

                <br>
                <address>
                    <?php echo e($toko['address']); ?>

                </address>
            </td>
        </tr>
        <tr>
            <td>
                No
            </td>
            <td>: <?php echo e($hutang->kode); ?></td>
        </tr>
        <tr>
            <td>Type</td>
            <td>: <?php echo e($hutang->po === 'True' ? "Purchase Order" : "Pembelian Langsung"); ?></td>
        <tr>
            <td>
                Supplier
            </td>
            <td>: <?php echo e($hutang->nama_supplier); ?>

                <?php if($hutang->alamat_supplier): ?>
                <br>
                <address>
                    <?php echo e($hutang->alamat_supplier ?? '-'); ?>

                </address>
                <?php endif; ?>
                <br>
            </td>
        </tr>
        <tr>
            <td>Operator : <?php echo e(strtoupper($hutang->operator)); ?></td>
            <td>Status : <?php if(intval($hutang->jml_hutang) === 0): ?> Lunas <?php else: ?> Angsuran <?php endif; ?></td>
        </tr>
    </table>

    <table class="data" width="100%">
        <thead>
            <tr>
                <th>Kode Barang</th>
                <th>Nama Barang</th>
                <th>Harga Beli</th>
                <th>Qty</th>
                <th>Jumlah</th>
                <th>Dibayarkan</th>
                <th>Hutang</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?php echo e($hutang->nama_barang); ?></td>
                <td><?php echo e($hutang->kode_barang); ?></td>
                <td class="text-right"><?php echo e($helpers->format_uang($hutang->harga_beli)); ?></td>
                <td class="text-right"><?php echo e(round($hutang->qty)." ".$hutang->satuan); ?></td>
                <td class="text-right"><?php echo e($helpers->format_uang($hutang->jumlah_pembelian)); ?></td>
                <td class="text-right"><?php echo e($helpers->format_uang($hutang->jumlah_pembelian - $hutang->hutang)); ?></td>
                <td class="text-right"><?php echo e($helpers->format_uang($hutang->hutang)); ?></td>
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="6" class="text-right"><b>Total Harga</b></td>
                <td class="text-right"><b><?php echo e($helpers->format_uang($hutang->jumlah_pembelian)); ?></b></td>
            </tr>
            <tr>
                <td colspan="6" class="text-right"><b>Diskon</b></td>
                <td class="text-right"><b><?php echo e($helpers->format_uang($hutang->diskon)); ?></b></td>
            </tr>
            <tr>
                <td colspan="6" class="text-right"><b>Diterima</b></td>
                <td class="text-right"><b><?php echo e($helpers->format_uang($hutang->diterima)); ?></b></td>
            </tr>
            <?php if($hutang->visa === 'HUTANG'): ?>
            <tr>
                <td colspan="6" class="text-right"><b>Hutang</b></td>
                <td class="text-right"><b><?php echo e($helpers->format_uang($hutang->hutang)); ?></b></td>
            </tr>
            <?php if($hutang->angsuran_ke > 0): ?>
            <?php $__currentLoopData = $angsurans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $angsuran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="6" class="text-right"><b>Angsuran ke <?php echo e($angsuran->angsuran_ke); ?></b></td>
                <td class="text-right"><b><?php echo e($helpers->format_uang($angsuran->bayar_angsuran)); ?></b></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <tr>
                <td colspan="6" class="text-right"><b>Sisa Hutang:</b></td>
                <td class="text-right"><b><?php echo e($helpers->format_uang($hutang->jml_hutang)); ?></b></td>
            </tr>
            <?php else: ?>
            <tr>
                <td colspan="6" class="text-right"><b>Kembali</b></td>
                <td class="text-right"><b><?php echo e($helpers->format_uang($hutang->diterima - $hutang->jumlah)); ?></b></td>
            </tr>
            <?php endif; ?>
        </tfoot>
    </table>

  
</body>
</html><?php /**PATH /var/www/html/sirmuh-pos-api-backend/resources/views/bayar-hutang/nota_besar.blade.php ENDPATH**/ ?>