<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: none;
            padding: 8px;
            text-align: left;
            max-width: 130px; /* Set a maximum width for each cell */
            overflow: hidden;
            white-space: nowrap;
            /*text-overflow: ellipsis;*/
            font-size: 9.5px; 
        }

        th {
            background-color: #8a8a8a; /* Header background color */
        }

        tbody th, tbody td {
            border: none; /* Remove border for table rows */
        }

        tfoot {
            border-top: 2px solid #000;
            border-bottom: 2px solid #000;
            font-size: 11px;
            font-weight: 900;
        }

        tfoot tr, td {
            border: none;
        }
    </style>
</head>
<body>
    <img src="<?php echo e(public_path('storage/tokos/' . $perusahaan['logo'])); ?>" alt="<?php echo e($perusahaan['logo']); ?>" width="100">
    <h5><?php echo e($perusahaan->name); ?></h5>
    <address style="margin-top: -23px;font-size:9px;">
        <?php echo e($perusahaan->address); ?>

    </address>


    <h3>Laporan Pembelian</h3>
    <hr style="margin-top:-.7rem;">
    <ul style="list-style: none; margin-left:-2rem;margin-top:-.2rem;">
        <li style="font-size: 10px;">PERIODE : <?php echo e($periode['start_date']); ?> S/D <?php echo e($periode['end_date']); ?></li>
    </ul>
    <hr style="margin-top:-.7rem;">

    <table>
        <thead>
            <tr>
                <th width="50">Tanggal</th>
                <th width="50">No Faktur</th>
                <th>Supplier</th>
                <th>Operator</th>
                <th>Pembayaran</th>
                <th>Disc</th>
                <th>PPN</th>
                <th>Jumlah</th>
                <!-- Add more columns based on your query -->
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $pembelians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pembelian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($pembelian->tanggal); ?></td>
                <td><?php echo e($pembelian->kode); ?></td>
                <td><?php echo e($pembelian->nama_supplier); ?></td>
                <td><?php echo e($pembelian->operator); ?></td>
                <td><?php echo e($pembelian->lunas ? "Lunas" : "Hutang"); ?></td>
                <td><?php echo e(round($pembelian->diskon)); ?></td>
                <td><?php echo e(round($pembelian->tax)); ?></td>
                <td><?php echo e($pembelian->jumlah); ?></td>
                <!-- Add more columns based on your query -->
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="6"></td>
                <td>Total</td>
                <td>Rp. <?php echo e($pembelians->sum('jumlah')); ?></td>
            </tr>
        </tfoot>
    </table>
</body>
</html>
<?php /**PATH /var/www/html/sirmuh-pos-api-backend/resources/views/laporan/laporan-pembelian-periode/download.blade.php ENDPATH**/ ?>