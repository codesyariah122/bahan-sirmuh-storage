<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Nota Pembayaran Hutang -  <?php echo e($kode); ?></title>

    <?php
    $style = '
    <style>
        * {
            font-family: "consolas", sans-serif;
        }
        p {
            display: block;
            margin: 3px;
            font-size: 10pt;
        }
        table td {
            font-size: 9pt;
        }
        .text-center {
            text-align: center;
        }
        .text-right {
            text-align: right;
        }

        @media print {
            @page {
                margin: 0;
                size: 75mm 
                ';
                ?>
                <?php 
                $style .= 
                ! empty($_COOKIE['innerHeight'])
                ? $_COOKIE['innerHeight'] .'mm; }'
                : '}';
                ?>
                <?php
                $style .= '
                html, body {
                    width: 70mm;
                }
                .btn-print {
                    display: none;
                }
            }
        </style>
        ';
        ?>

        <?php echo $style; ?>

    </head>
    <body onload="window.print()">
        <button class="btn-print" style="position: absolute; right: 1rem; top: rem;" onclick="window.print()">Print</button>
       
        <div class="clear-both" style="clear: both;"></div>
        <p>No: <?php echo e($hutang->kode); ?></p>
        <p>Type: <?php echo e($hutang->po === 'True' ? "Purchase Order" : "Pembelian Langsung"); ?></p>
        <p class="text-center">===================================</p>
        <p>
            <img src="<?php echo e(Storage::url('tokos/' . $toko['logo'])); ?>" width="70">
        </p>
        <p><?php echo e($toko['name']); ?></p>
        <p><?php echo e($toko['address']); ?></p>
        <br/>
        <p>No : <?php echo e($hutang->kode); ?></p>
        <p>Tgl Transaksi : <?php echo e($hutang->tanggal); ?></p>
        <p>Supplier : <?php echo e($hutang->nama_supplier); ?></p>
        <p>Kode Supplier : <?php echo e($hutang->supplier); ?></p>
        <p>Alamat Supplier : <?php echo e($hutang->alamat_supplier); ?></p>
        <p>Operator : <?php echo e(strtoupper($hutang->operator)); ?></p>
        
        <p class="text-center">===================================</p>
        <table width="100%" style="border: 0;">
            <tr>
                <td colspan="3"><?php echo e($hutang->nama_barang); ?> - <?php echo e($hutang->kode_barang); ?></td>
            </tr>
            <tr>
                <td><?php echo e(round($hutang->qty)); ?> x <?php echo e($helpers->format_uang($hutang->harga_beli)); ?></td>
                <td></td>
                <td class="text-right"><?php echo e($helpers->format_uang($hutang->jumlah_pembelian)); ?></td>
            </tr>
        </table>
        <p class="text-center">-----------------------------------</p>
        <table width="100%" style="border: 0;">
            <tr>
                <td>Total Bayar:</td>
                <td class="text-right"><?php echo e($helpers->format_uang($hutang->jumlah_pembelian)); ?></td>
            </tr>
            <tr>
                <td>Total Item:</td>
                <td class="text-right">
                     <?php echo e(round($hutang->qty)); ?>

                 </td>
            </tr>
            <tr>
                <td>Diterima:</td>
                <td class="text-right"><?php echo e($helpers->format_uang($hutang->jumlah_pembelian - $hutang->hutang)); ?></td>
            </tr>
            <tr>
                <td>Diskon:</td>
                <td class="text-right"><?php echo e($helpers->format_uang($hutang->diskon)); ?></td>
            </tr>
            <tr>
                <td>Hutang:</td>
                <td class="text-right"><?php echo e($helpers->format_uang($hutang->hutang)); ?></td>
            </tr>
            <?php if($hutang->visa === "HUTANG"): ?>
            <?php $__currentLoopData = $angsurans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $angsuran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>Angsuran ke <?php echo e($angsuran->angsuran_ke); ?>:</td>
                <td class="text-right"><?php echo e($helpers->format_uang($angsuran->bayar_angsuran)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>Sisa Hutang:</td>
                <td class="text-right"><?php echo e($helpers->format_uang($hutang->jml_hutang)); ?></td>
            </tr>
            <?php else: ?>
            <tr>
                <td>Kembali:</td>
                <td class="text-right"><?php echo e($helpers->format_uang($hutang->bayar - $hutang->hutang)); ?></td>
            </tr>
            <?php endif; ?>
            <?php if(count($angsurans) > 0): ?>
            <tr>
                <td>Status:</td>
                <td class="text-right"><?php echo e(intval($hutang->jml_hutang) === 0 ? "Lunas" : "Angsuran"); ?></td>
            </tr>
            <?php else: ?>
            <tr>
                <td>Status:</td>
                <td class="text-right">Hutang</td>
            </tr>
            <?php endif; ?>
        </table>

        <p class="text-center">===================================</p>
        <p class="text-center">-- TERIMA KASIH --</p>

        <script>
            let body = document.body;
            let html = document.documentElement;
            let height = Math.max(
                body.scrollHeight, body.offsetHeight,
                html.clientHeight, html.scrollHeight, html.offsetHeight
                );

            document.cookie = "innerHeight=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
            document.cookie = "innerHeight="+ ((height + 50) * 0.264583);
        </script>
    </body>
    </html><?php /**PATH /var/www/html/sirmuh-pos-api-backend/resources/views/bayar-hutang/nota_kecil.blade.php ENDPATH**/ ?>