<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($penjualan->visa !== "HUTANG" ? 'Nota Penjualan' : 'Nota Piutang Penjualan'); ?> -  <?php echo e($kode); ?></title>

    <style>
        table td {
            /* font-family: Arial, Helvetica, sans-serif; */
            font-size: 10px;
        }
        table.data td,
        table.data th {
            border: 1px solid #ccc;
            padding: 5px;
            font-size: 10px;
        }
        table.data {
            border-collapse: collapse;
        }
        .text-center {
            text-align: center;
        }
        .text-right {
            text-align: right;
        }
    </style>
</head>
<body>
    <table width="100%">
        <tr>
            <td rowspan="6" width="60%">
                <img src="<?php echo e(public_path('storage/tokos/' . $toko['logo'])); ?>" alt="<?php echo e($toko['logo']); ?>" width="100">
                <br>
                <?php echo e($toko['name']); ?>

                <br>
                <address>
                    <?php echo e($toko['address']); ?>

                </address>
            </td>
        </tr>
        <tr>
            <td>
                No
            </td>
            <td>: <?php echo e($penjualan->kode); ?></td>
        </tr>
        <tr>
            <td>Type</td>
            <td>: Penjualan Toko</td>
        <tr>
            <td>
                Pelanggan
            </td>
            <td>: <?php echo e($penjualan->pelanggan_nama); ?>

                <?php if($penjualan->pelanggan_alamat): ?>
               <br>
               <address>
                <?php echo e($penjualan->pelanggan_alamat ?? '-'); ?>

                </address>
                <?php endif; ?>
                <br>
            </td>
        </tr>
        <?php if($penjualan->lunas !== "True"): ?>
        <tr>
            <td>
                Jenis Pembayaran
            </td>
            <td>: <?php echo e($penjualan->visa); ?></td>
        </tr>
        <?php endif; ?>
    </table>

    <table class="data" width="100%" style="margin-top:15px;">
        <thead>
            <tr>
                <th>No</th>
                <th>Kode</th>
                <th>Kode Kas</th>
                <th>Barang / Harga Satuan</th>
                <th>Jumlah</th>
                <th>Diskon</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="text-center"><?php echo e($key+1); ?></td>
                <td class="text-center"><?php echo e($item->kode); ?></td>
                <td class="text-center"><?php echo e($item->kode_kas); ?></td>
                <td class="text-center"><?php echo e($item->barang_nama); ?> / <?php echo e($helpers->format_uang($item->hpp)); ?></td>
                <td class="text-right"><?php echo e(round($item->qty)." ".$item->satuan); ?></td>
                <td class="text-right"><?php echo e($item->diskon); ?>%</td>
                <td class="text-right"><?php echo e($item->diskon ? $helpers->format_uang($item->diskon_rupiah) : $helpers->format_uang($item->subtotal)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="6" class="text-right"><b>Total</b></td>
                <td class="text-right"><b><?php echo e($helpers->format_uang($penjualan->jumlah)); ?></b></td>
            </tr>
            <tr>
                <td colspan="6" class="text-right"><b>Diskon</b></td>
                <td class="text-right"><b><?php echo e($helpers->format_uang($penjualan->diskon)); ?>%</b></td>
            </tr>
            <?php if($penjualan->lunas === "True"): ?>
            <tr>
                <td colspan="6" class="text-right"><b>Total Bayar</b></td>
                <td class="text-right"><b><?php echo e($item->diskon ? $helpers->format_uang($item->diskon_rupiah) : $helpers->format_uang($penjualan->bayar)); ?></b></td>
            </tr>
            <?php endif; ?>
            <tr>
                <td colspan="6" class="text-right"><b>Diterima</b></td>
                <td class="text-right"><b><?php echo e($penjualan->diterima ? $helpers->format_uang($penjualan->diterima) : $helpers->format_uang($penjualan->bayar)); ?></b></td>
            </tr>
            <?php if($penjualan->lunas === "True"): ?>
            <tr>
                <td colspan="6" class="text-right"><b>Kembali</b></td>
                <td class="text-right"><b><?php echo e($penjualan->kembali ? $helpers->format_uang($penjualan->kembali) : $helpers->format_uang($penjualan->bayar - $penjualan->jumlah)); ?></b></td>
            </tr>
            <?php else: ?>
            <tr>
                <td colspan="6" class="text-right"><b>Masuk Piutang</b></td>
                <td class="text-right"><b><?php echo e($helpers->format_uang($penjualan->piutang)); ?></b></td>
            </tr>
            <?php endif; ?>
        </tfoot>
    </table>

      <table width="100%" style="margin-top: 2rem;">
        <tr>
            <td class="text-right">
                <h2>Kasir</h2>
                <br>
                <br>
                <b><?php echo e(strtoupper($penjualan->operator)); ?></b>
            </td>
        </tr>
    </table>

    <p style="text-align: center; margin-top: 20px;font-size:10px;">
        <p class="text-center">Semoga Lancar</p>
        <p class="text-center">&</p>
        <p class="text-center">Tetap Menjadi Langganan</p>
        <p class="text-center">*** TERIMA KASIH ****</p>
    </p>
</body>
</html><?php /**PATH /var/www/html/sirmuh-pos-api-backend/resources/views/penjualan/nota_besar.blade.php ENDPATH**/ ?>